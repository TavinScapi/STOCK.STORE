const itensPreDefinidos = [
  {
    id: 1,
    nome: 'Clips para Papel',
    categoria: 'Material de Escritório',
    quantidade: 200,
    preco: 25.00
  },
  {
    id: 2,
    nome: 'Perfurador de Papel',
    categoria: 'Material de Escritório',
    quantidade: 15,
    preco: 80.00
  },
  {
    id: 3,
    nome: 'Agenda 2024',
    categoria: 'Material de Escritório',
    quantidade: 30,
    preco: 45.00
  },
  {
    id: 4,
    nome: 'Marcador de Texto Amarelo',
    categoria: 'Material de Escritório',
    quantidade: 50,
    preco: 60.00
  },
  {
    id: 5,
    nome: 'Bloco de Notas',
    categoria: 'Material de Escritório',
    quantidade: 100,
    preco: 30.00
  },
  {
    id: 6,
    nome: 'Pastas de Arquivo',
    categoria: 'Material de Escritório',
    quantidade: 10,
    preco: 90.00
  },
  {
    id: 7,
    nome: 'Caneta Gel Azul',
    categoria: 'Material de Escritório',
    quantidade: 36,
    preco: 40.00
  },
  {
    id: 8,
    nome: 'Carregador de Bateria',
    categoria: 'Acessórios',
    quantidade: 8,
    preco: 120.00
  },
  {
    id: 9,
    nome: 'Calculadora de Mesa',
    categoria: 'Material de Escritório',
    quantidade: 20,
    preco: 150.00
  },
  {
    id: 10,
    nome: 'Organizador de Mesa',
    categoria: 'Material de Escritório',
    quantidade: 5,
    preco: 55.00
  }
];


// Carregar estoque e pedidos pendentes
let estoque = JSON.parse(localStorage.getItem('estoque')) || {};
let pedidosPendentes = JSON.parse(localStorage.getItem('pedidosPendentes')) || [];

// Função para adicionar itens pré-definidos se não estiverem no estoque
function inicializarEstoque() {
  itensPreDefinidos.forEach(item => {
    if (!estoque[item.nome]) {
      estoque[item.nome] = {
        id: item.id,
        nome: item.nome,
        categoria: item.categoria,
        quantidade: item.quantidade,
        preco: item.preco
      };
    }
  });

  // Salvar o estoque atualizado no localStorage
  localStorage.setItem('estoque', JSON.stringify(estoque));
}

// Função para renderizar a tabela de estoque
function renderEstoque() {
  const tabela = document.getElementById('estoqueTabela');
  tabela.innerHTML = '';

  for (let produto in estoque) {
    const row = document.createElement('tr');

    // Define a classe de estilização com base na quantidade
    let quantidadeClass = '';
    if (estoque[produto].quantidade < 10) {
      quantidadeClass = 'quantidade-baixa'; // Quantidade baixa, cor vermelha
    } else if (estoque[produto].quantidade > 50) {
      quantidadeClass = 'quantidade-alta'; // Quantidade alta, cor verde
    }

    // Renderiza a linha da tabela com a classe aplicada à quantidade
    row.innerHTML = `
      <td>${estoque[produto].id}</td>
      <td>${produto}</td>
      <td>${estoque[produto].categoria}</td>
      <td class="${quantidadeClass}">${estoque[produto].quantidade}</td>
      <td>R$ ${estoque[produto].preco.toFixed(2)}</td>
    `;
    tabela.appendChild(row);
  }
}

// Função para adicionar pedidos à lista de pendentes
document.getElementById('entradaForm')?.addEventListener('submit', function (event) {
  event.preventDefault();

  const nome = document.getElementById('produto').value;
  const categoria = document.getElementById('categoria').value;
  const quantidade = parseInt(document.getElementById('quantidade').value);
  const preco = parseFloat(document.getElementById('preco').value);

  // Adicionar pedido à lista de pendentes
  pedidosPendentes.push({ nome, categoria, quantidade, preco });
  localStorage.setItem('pedidosPendentes', JSON.stringify(pedidosPendentes));

  alert('Pedido adicionado à lista de pendentes!');
  renderPedidosPendentes();

  // Limpar o formulário
  document.getElementById('entradaForm').reset();
});

// Função para renderizar a tabela de pedidos pendentes
function renderPedidosPendentes() {
  const tabela = document.getElementById('pedidosPendentesTabela');
  tabela.innerHTML = '';

  pedidosPendentes.forEach((pedido, index) => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${pedido.nome}</td>
      <td>${pedido.categoria}</td>
      <td>${pedido.quantidade}</td>
      <td>R$ ${pedido.preco.toFixed(2)}</td>
      <td><button class="confirm-btn" data-index="${index}">Confirmar Entrega</button></td>
    `;
    tabela.appendChild(row);
  });

  // Adicionar eventos de confirmação
  document.querySelectorAll('.confirm-btn').forEach(button => {
    button.addEventListener('click', function () {
      const index = this.getAttribute('data-index');
      confirmarEntrega(index);
    });
  });
}

// Função para confirmar a entrega e mover para o estoque
function confirmarEntrega(index) {
  const pedido = pedidosPendentes[index];

  // Se o produto já existe no estoque, apenas atualize a quantidade
  if (estoque[pedido.nome]) {
    estoque[pedido.nome].quantidade += pedido.quantidade;
  } else {
    // Se o produto não existe, adicione ao estoque
    const id = Object.keys(estoque).length + 1;
    estoque[pedido.nome] = {
      id: id,
      nome: pedido.nome,
      categoria: pedido.categoria,
      quantidade: pedido.quantidade,
      preco: pedido.preco
    };
  }

  // Remove o pedido pendente
  pedidosPendentes.splice(index, 1);
  localStorage.setItem('pedidosPendentes', JSON.stringify(pedidosPendentes));
  localStorage.setItem('estoque', JSON.stringify(estoque));

  alert('Entrega confirmada e produto adicionado ao estoque!');
  renderPedidosPendentes();
  renderEstoque();
}

// Função para saída de produtos
document.getElementById('saidaForm')?.addEventListener('submit', function (event) {
  event.preventDefault();

  const idProduto = parseInt(document.getElementById('idProdutoSaida').value);
  const quantidadeSaida = parseInt(document.getElementById('quantidadeSaida').value);

  // Procurar o produto com base no ID
  let produtoEncontrado = null;
  for (let produto in estoque) {
    if (estoque[produto].id === idProduto) {
      produtoEncontrado = estoque[produto];
      break;
    }
  }

  // Verificar se o produto foi encontrado
  if (!produtoEncontrado) {
    alert('ID do produto não encontrado.');
    return;
  }

  // Verificar se a quantidade disponível é suficiente
  if (produtoEncontrado.quantidade < quantidadeSaida) {
    alert('Quantidade insuficiente em estoque.');
    return;
  }

  // Atualizar o estoque, reduzindo apenas a quantidade especificada
  produtoEncontrado.quantidade -= quantidadeSaida;
  if (produtoEncontrado.quantidade === 0) {
    delete estoque[produtoEncontrado.nome]; // Remove o produto se a quantidade for zero
  }

  // Salvar o estoque atualizado no localStorage
  localStorage.setItem('estoque', JSON.stringify(estoque));

  alert('Quantidade removida do estoque!');
  renderEstoque();
  window.location.href = 'index.html';
});

// Inicializa o estoque e renderiza as tabelas na carga da página
document.addEventListener('DOMContentLoaded', function () {
  inicializarEstoque();
  renderEstoque();
  renderPedidosPendentes();
});

const produtos = document.querySelectorAll('#estoqueTabela tr');

produtos.forEach(produto => {
    const quantidade = parseInt(produto.querySelector('td:nth-child(4)').textContent); // Seleciona a quantidade
    
    const quantidadeTd = produto.querySelector('td:nth-child(4)'); // Seleciona a célula da quantidade

    if (quantidade < 10) {
        quantidadeTd.style.color = 'red'; // Vermelho para quantidade menor que 10
    } else if (quantidade > 50) {
        quantidadeTd.style.color = 'green'; // Verde para quantidade maior que 50
    } else {
        quantidadeTd.style.color = 'black'; // Preto para quantidades entre 10 e 50
    }
});
